PrintOdds(1,20);
DecreasingMultiples(3,100);
PrintTheSequence([4,2.5,1,-0.5,-2,-3.5]);
Sigma(1,100);
Factorial(1,12);

function PrintOdds(start, end) {
    var result = "";
    for (var k = 0;k <= end; k++) {
        if ((k % 2) != 0) {
            if (k < (end-1)) {
                result = result + `${k}, `;
            }
            else {
                result = result + `${k}`;
            }
        }
    }
    console.log(`PrintOdds(${start},${end}) = ${result}`)
}
function DecreasingMultiples(multiple, upperLimit){
    var result = "";
    for (var k = upperLimit; k >= 0; k--) {
        if ((k % multiple) == 0) {
            if (k > multiple) {
                result = result + `${k} , `;
            }
            else if (k == multiple) {
                result = result + `${k}`;
            }
        }
    }
    console.log(`DecreasingMultiples(${multiple},${upperLimit}) = ${result}`);
}
function PrintTheSequence(values) {
    var result = "";
    for (var k = 0; k < values.length; k++) {
        if (k < (values.length-1)) {
            result = result + `${values[k]} , `
        }
        else {
            result = result + `${values[k]}`
        }
    }
    console.log("PrintTheSequence = " + result);
}
function Sigma(start, end) {
    var sum = 0;
    var k = start;
    while (k <= end) {
        sum = sum + k;
        k++
    }
    console.log(`Sigma(${start},${end}) = ${sum}`);
}
function Factorial(start, end) {
    var factor = start;
    var k = start+1;
    while (k <= end) {
        factor = factor * k;
        k++;
    }
    console.log(`Factorial(${start},${end}) = ${factor}`);
}